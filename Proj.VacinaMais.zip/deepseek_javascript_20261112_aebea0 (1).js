// =============================================
// MaisVacina — Lógica com login, e-mail e recuperação
// =============================================

document.addEventListener('DOMContentLoaded', () => {

    // ---- Máscara de CPF (inclui o campo de recuperação) ----
    ['login-cpf', 'cad-cpf', 'rec-cpf'].forEach(id => {
        const el = document.getElementById(id);
        if (!el) return;
        el.addEventListener('input', e => {
            e.target.value = formatarCPF(e.target.value);
        });
    });

    // ---- Alternância de abas (Entrar / Criar Conta) ----
    document.querySelectorAll('.aba-login').forEach(btn => {
        btn.addEventListener('click', () => {
            document.querySelectorAll('.aba-login').forEach(b => b.classList.remove('ativa'));
            document.querySelectorAll('.form-aba').forEach(f => f.classList.remove('ativa'));
            btn.classList.add('ativa');
            const alvo = btn.dataset.aba === 'login' ? 'form-login' : 'form-cadastro-conta';
            document.getElementById(alvo).classList.add('ativa');
        });
    });

    // ---- NOVO: link "Esqueci minha senha" ----
    document.getElementById('link-esqueci-senha').addEventListener('click', (e) => {
        e.preventDefault();
        document.querySelectorAll('.aba-login').forEach(b => b.classList.remove('ativa'));
        document.querySelectorAll('.form-aba').forEach(f => f.classList.remove('ativa'));
        document.getElementById('form-recuperar').classList.add('ativa');
    });

    // ---- NOVO: link "Voltar ao login" ----
    document.getElementById('link-voltar-login').addEventListener('click', (e) => {
        e.preventDefault();
        document.getElementById('form-recuperar').classList.remove('ativa');
        document.querySelector('.aba-login[data-aba="login"]').classList.add('ativa');
        document.getElementById('form-login').classList.add('ativa');
    });

    // ---- Login ----
    document.getElementById('form-login').addEventListener('submit', e => {
        e.preventDefault();
        const cpf = document.getElementById('login-cpf').value.replace(/\D/g, '');
        const senha = document.getElementById('login-senha').value;

        if (!validarCPF(cpf)) {
            exibirMsg('msg-login', '❌ CPF inválido.', 'erro');
            return;
        }
        const contas = getContas();
        const conta = contas[cpf];
        if (!conta) {
            exibirMsg('msg-login', '❌ CPF não cadastrado. Crie uma conta.', 'erro');
            return;
        }
        if (conta.senha !== senha) {
            exibirMsg('msg-login', '❌ Senha incorreta.', 'erro');
            return;
        }
        setSessao(cpf);
        document.getElementById('form-login').reset();
        iniciarApp();
    });

    // ---- Cadastro de conta (agora com e-mail) ----
    document.getElementById('form-cadastro-conta').addEventListener('submit', e => {
        e.preventDefault();
        const cpf = document.getElementById('cad-cpf').value.replace(/\D/g, '');
        const dados = {
            cpf,
            nome: document.getElementById('cad-nome').value.trim(),
            email: document.getElementById('cad-email').value.trim().toLowerCase(),
            sexo: document.getElementById('cad-sexo').value,
            nascimento: document.getElementById('cad-nascimento').value,
            telefone: document.getElementById('cad-telefone').value.trim(),
            endereco: document.getElementById('cad-endereco').value.trim(),
            senha: document.getElementById('cad-senha').value
        };
        const confirmar = document.getElementById('cad-confirmar').value;

        if (!validarCPF(cpf)) {
            exibirMsg('msg-cadastro-conta', '❌ CPF inválido.', 'erro');
            return;
        }
        if (!validarEmail(dados.email)) {
            exibirMsg('msg-cadastro-conta', '❌ E-mail inválido.', 'erro');
            return;
        }
        if (dados.senha !== confirmar) {
            exibirMsg('msg-cadastro-conta', '❌ As senhas não coincidem.', 'erro');
            return;
        }
        const contas = getContas();
        if (contas[cpf]) {
            exibirMsg('msg-cadastro-conta', '❌ Já existe uma conta com este CPF.', 'erro');
            return;
        }
        contas[cpf] = dados;
        salvarContas(contas);
        exibirMsg('msg-cadastro-conta', '✅ Conta criada! Faça login para entrar.', 'sucesso');
        setTimeout(() => {
            document.querySelector('.aba-login[data-aba="login"]').click();
            document.getElementById('login-cpf').value = formatarCPF(cpf);
            document.getElementById('form-cadastro-conta').reset();
        }, 1200);
    });

    // ---- NOVO: Recuperação de senha ----
    document.getElementById('form-recuperar').addEventListener('submit', e => {
        e.preventDefault();
        const cpf = document.getElementById('rec-cpf').value.replace(/\D/g, '');
        const email = document.getElementById('rec-email').value.trim().toLowerCase();
        const novaSenha = document.getElementById('rec-nova-senha').value;
        const confirmar = document.getElementById('rec-confirmar').value;

        if (!validarCPF(cpf)) {
            exibirMsg('msg-recuperar', '❌ CPF inválido.', 'erro');
            return;
        }
        const contas = getContas();
        const conta = contas[cpf];

        // Verificações de segurança (CPF + e-mail precisam bater)
        if (!conta) {
            exibirMsg('msg-recuperar', '❌ CPF não encontrado.', 'erro');
            return;
        }
        if (conta.email !== email) {
            exibirMsg('msg-recuperar', '❌ E-mail não corresponde ao cadastrado.', 'erro');
            return;
        }
        if (novaSenha !== confirmar) {
            exibirMsg('msg-recuperar', '❌ As senhas não coincidem.', 'erro');
            return;
        }

        // Atualiza a senha
        contas[cpf].senha = novaSenha;
        salvarContas(contas);

        exibirMsg('msg-recuperar', '✅ Senha redefinida! Faça login com a nova senha.', 'sucesso');
        setTimeout(() => {
            document.getElementById('form-recuperar').reset();
            document.getElementById('link-voltar-login').click();
            document.getElementById('login-cpf').value = formatarCPF(cpf);
        }, 1500);
    });

    // ---- Logout ----
    document.getElementById('btn-logout').addEventListener('click', () => {
        limparSessao();
        document.getElementById('app-main').style.display = 'none';
        document.getElementById('usuario-info').style.display = 'none';
        document.getElementById('tela-login').style.display = 'block';
        document.getElementById('form-login').reset();
        document.getElementById('form-recuperar').reset();
        document.getElementById('form-vacina').reset();
        document.getElementById('form-autenticacao').reset();
        // volta pra aba de login
        document.querySelectorAll('.aba-login').forEach(b => b.classList.remove('ativa'));
        document.querySelectorAll('.form-aba').forEach(f => f.classList.remove('ativa'));
        document.querySelector('.aba-login[data-aba="login"]').classList.add('ativa');
        document.getElementById('form-login').classList.add('ativa');
    });

    // ---- Vacinas ----
    document.getElementById('form-vacina').addEventListener('submit', e => {
        e.preventDefault();
        const cpf = getSessao();
        if (!cpf) return;
        const vacinas = getVacinas(cpf);
        vacinas.push({
            id: Date.now(),
            nome: document.getElementById('vacina-nome').value.trim(),
            data: document.getElementById('vacina-data').value,
            hora: document.getElementById('vacina-hora').value,
            local: document.getElementById('vacina-local').value.trim()
        });
        setVacinas(cpf, vacinas);
        document.getElementById('form-vacina').reset();
        renderizarVacinas();
    });

    // ---- Autenticação profissional ----
    document.getElementById('form-autenticacao').addEventListener('submit', e => {
        e.preventDefault();
        const cpf = getSessao();
        if (!cpf) return;
        const tipo = document.getElementById('tipo-profissional').value;
        const registro = document.getElementById('registro-profissional').value.trim();
        const senha = document.getElementById('senha-profissional').value.trim();

        if (!tipo || !registro || !senha) {
            exibirMsg('msg-autenticacao', '❌ Preencha todos os campos.', 'erro');
            return;
        }
        localStorage.setItem('maisvacina_autenticacao_' + cpf, JSON.stringify({
            tipo, registro, dataAutenticacao: new Date().toISOString()
        }));
        atualizarStatusAutenticacao();
        exibirMsg('msg-autenticacao', '✅ Carteira autenticada com sucesso!', 'sucesso');
    });

    // ---- Inicialização ----
    if (getSessao()) {
        iniciarApp();
    } else {
        document.getElementById('tela-login').style.display = 'block';
    }
});

// =============================================
// Funções utilitárias
// =============================================

function validarCPF(cpf) {
    cpf = cpf.replace(/\D/g, '');
    if (cpf.length !== 11 || /^(\d)\1{10}$/.test(cpf)) return false;
    for (let t = 9; t < 11; t++) {
        let d = 0;
        for (let c = 0; c < t; c++) {
            d += parseInt(cpf[c]) * ((t + 1) - c);
        }
        d = ((d * 10) % 11) % 10;
        if (parseInt(cpf[t]) !== d) return false;
    }
    return true;
}

function validarEmail(email) {
    return /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email);
}

function formatarCPF(value) {
    value = value.replace(/\D/g, '').slice(0, 11);
    return value
        .replace(/(\d{3})(\d)/, '$1.$2')
        .replace(/(\d{3})(\d)/, '$1.$2')
        .replace(/(\d{3})(\d{1,2})$/, '$1-$2');
}

function formatarData(iso) {
    if (!iso) return '';
    const [a, m, d] = iso.split('-');
    return `${d}/${m}/${a}`;
}

function exibirMsg(id, texto, tipo) {
    const el = document.getElementById(id);
    el.textContent = texto;
    el.className = `mensagem ${tipo}`;
    setTimeout(() => { el.textContent = ''; }, 5000);
}

// --- Contas e sessão ---
function getContas() {
    return JSON.parse(localStorage.getItem('maisvacina_accounts') || '{}');
}
function salvarContas(c) {
    localStorage.setItem('maisvacina_accounts', JSON.stringify(c));
}
function getSessao() {
    return localStorage.getItem('maisvacina_session');
}
function setSessao(cpf) {
    localStorage.setItem('maisvacina_session', cpf);
}
function limparSessao() {
    localStorage.removeItem('maisvacina_session');
}

// --- Vacinas por CPF ---
function getVacinas(cpf) {
    return JSON.parse(localStorage.getItem('maisvacina_vacinas_' + cpf) || '[]');
}
function setVacinas(cpf, arr) {
    localStorage.setItem('maisvacina_vacinas_' + cpf, JSON.stringify(arr));
}
function getAutenticacao(cpf) {
    return JSON.parse(localStorage.getItem('maisvacina_autenticacao_' + cpf) || 'null');
}

// --- Inicialização do app após login ---
function iniciarApp() {
    const cpf = getSessao();
    const conta = getContas()[cpf];
    if (!conta) { limparSessao(); return; }

    document.getElementById('tela-login').style.display = 'none';
    document.getElementById('app-main').style.display = 'block';
    document.getElementById('usuario-info').style.display = 'flex';
    document.getElementById('nome-usuario').textContent = conta.nome;

    renderizarPerfil();
    renderizarVacinas();
    atualizarStatusAutenticacao();
}

// --- Perfil (agora com e-mail) ---
function renderizarPerfil() {
    const cpf = getSessao();
    const conta = getContas()[cpf];
    if (!conta) return;
    const view = document.getElementById('perfil-view');

    view.innerHTML = `
        <div class="perfil-grid">
            <div class="perfil-item"><small>Nome</small><strong>${conta.nome}</strong></div>
            <div class="perfil-item"><small>CPF</small><strong>${formatarCPF(conta.cpf)}</strong></div>
            <div class="perfil-item"><small>E-mail</small><strong>${conta.email || '—'}</strong></div>
            <div class="perfil-item"><small>Sexo</small><strong>${conta.sexo}</strong></div>
            <div class="perfil-item"><small>Nascimento</small><strong>${formatarData(conta.nascimento)}</strong></div>
            <div class="perfil-item"><small>Telefone</small><strong>${conta.telefone}</strong></div>
            <div class="perfil-item" style="grid-column:1/-1;"><small>Endereço</small><strong>${conta.endereco}</strong></div>
        </div>
        <button class="btn-secundario" id="btn-editar-perfil" style="margin-top:12px;">Editar Dados</button>
    `;

    document.getElementById('btn-editar-perfil').addEventListener('click', () => {
        view.innerHTML = `
            <form id="form-editar-perfil">
                <div class="grid-2">
                    <div class="campo"><label>Nome</label><input type="text" id="edit-nome" value="${conta.nome}" required></div>
                    <div class="campo"><label>E-mail</label><input type="email" id="edit-email" value="${conta.email || ''}" required></div>
                    <div class="campo"><label>Sexo</label>
                        <select id="edit-sexo" required>
                            <option ${conta.sexo === 'Feminino' ? 'selected' : ''}>Feminino</option>
                            <option ${conta.sexo === 'Masculino' ? 'selected' : ''}>Masculino</option>
                            <option ${conta.sexo === 'Outro' ? 'selected' : ''}>Outro</option>
                            <option ${conta.sexo === 'Prefiro não informar' ? 'selected' : ''}>Prefiro não informar</option>
                        </select>
                    </div>
                    <div class="campo"><label>Nascimento</label><input type="date" id="edit-nascimento" value="${conta.nascimento}" required></div>
                    <div class="campo"><label>Telefone</label><input type="tel" id="edit-telefone" value="${conta.telefone}" required></div>
                    <div class="campo" style="grid-column:1/-1;"><label>Endereço</label><input type="text" id="edit-endereco" value="${conta.endereco}" required></div>
                </div>
                <button type="submit" class="btn-primario">Salvar Alterações</button>
                <button type="button" class="btn-secundario" id="btn-cancelar-edicao" style="margin-left:8px;">Cancelar</button>
            </form>
        `;
        document.getElementById('form-editar-perfil').addEventListener('submit', ev => {
            ev.preventDefault();
            const novoEmail = document.getElementById('edit-email').value.trim().toLowerCase();
            if (!validarEmail(novoEmail)) {
                alert('E-mail inválido.');
                return;
            }
            const contas = getContas();
            contas[cpf].nome = document.getElementById('edit-nome').value.trim();
            contas[cpf].email = novoEmail;
            contas[cpf].sexo = document.getElementById('edit-sexo').value;
            contas[cpf].nascimento = document.getElementById('edit-nascimento').value;
            contas[cpf].telefone = document.getElementById('edit-telefone').value.trim();
            contas[cpf].endereco = document.getElementById('edit-endereco').value.trim();
            salvarContas(contas);
            document.getElementById('nome-usuario').textContent = contas[cpf].nome;
            renderizarPerfil();
        });
        document.getElementById('btn-cancelar-edicao').addEventListener('click', renderizarPerfil);
    });
}

// --- Vacinas ---
function renderizarVacinas() {
    const cpf = getSessao();
    const container = document.getElementById('lista-vacinas');
    const vacinas = getVacinas(cpf);

    if (vacinas.length === 0) {
        container.innerHTML = '<p class="vazio">Nenhuma vacina registrada ainda.</p>';
        return;
    }
    container.innerHTML = vacinas.map(v => `
        <div class="item-vacina">
            <div>
                <strong>${v.nome}</strong><br>
                <small>📅 ${formatarData(v.data)} às ${v.hora} — 📍 ${v.local}</small>
            </div>
            <button onclick="removerVacina(${v.id})" style="background:none;border:none;color:#e63946;cursor:pointer;font-size:1.2rem;" title="Remover">✕</button>
        </div>
    `).join('');
}

window.removerVacina = function (id) {
    if (!confirm('Remover esta vacina do histórico?')) return;
    const cpf = getSessao();
    let vacinas = getVacinas(cpf);
    vacinas = vacinas.filter(v => v.id !== id);
    setVacinas(cpf, vacinas);
    renderizarVacinas();
};

// --- Autenticação ---
function atualizarStatusAutenticacao() {
    const cpf = getSessao();
    const el = document.getElementById('status-autenticacao');
    const auth = getAutenticacao(cpf);
    if (auth) {
        el.className = 'status-autenticado';
        el.innerHTML = `✅ Carteira autenticada por <strong>${auth.tipo}</strong> — Registro: <strong>${auth.registro}</strong>`;
    } else {
        el.className = 'status-pendente';
        el.innerHTML = 'Status da carteira: <strong>Aguardando autenticação</strong>';
    }
}